#include <cstdint>

int64_t Sum(int64_t a, int64_t b) {
  return a + b;
}