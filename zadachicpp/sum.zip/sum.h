#ifndef OOP_ASSIGNMENTS_SUM_H
#define OOP_ASSIGNMENTS_SUM_H

int64_t Sum(int64_t, int64_t);

#endif