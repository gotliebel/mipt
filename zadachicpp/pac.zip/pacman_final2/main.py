from game import GamePlay
from menu import *

WIDTH = 1080
HEIGHT = 920
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
MIDNIGHTBLUE = (25, 25, 112)


def main():
    pygame.init()
    pygame.mixer.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("PackMan")
    clock = pygame.time.Clock()
    menu = Menu(True, False)
    menu.append_option('Start', lambda run: not run)
    menu.append_option('Quit', lambda run, game_over: (not run, not game_over))
    game = GamePlay(screen)
    run_main(menu, game, screen, clock)
    pygame.quit()

if __name__ == '__main__':
    main()
