from animation import Animation
import pygame
import random

WIDTH = 1080
HEIGHT = 920


class AbstractCreatures(pygame.sprite.Sprite):
    difference_x = 0
    difference_y = 0

    def __init__(self, image):
        pygame.sprite.Sprite.__init__(self)
        self.const_image = pygame.image.load(image).convert()
        self.const_image.set_colorkey((0, 0, 0))
        self.rect = self.const_image.get_rect()


class Player(AbstractCreatures):
    def __init__(self, x, y, image_filename):
        AbstractCreatures.__init__(self, image_filename)
        self.dead = False
        self.moment_image = pygame.image.load(image_filename).convert()
        self.animation_dead = Animation(pygame.image.load("explosion.png"), 30, 30)
        self.animation_rotate_image = pygame.image.load("walk.png")
        self.animation_move_right = Animation(self.animation_rotate_image, 32,
                                              32)
        self.animation_move_left = Animation(
            pygame.transform.rotate(self.animation_rotate_image, 180), 32, 32)
        self.animation_move_up = Animation(
            pygame.transform.rotate(self.animation_rotate_image, 90), 32, 32)
        self.animation_move_down = Animation(
            pygame.transform.rotate(self.animation_rotate_image, 270), 32, 32)
        self.moment_image.set_colorkey((0, 0, 0))
        self.rect.center = (x, y)
        self.score = 0

    def update(self):
        if not self.dead:
            if self.rect.left > WIDTH:
                self.rect.right = 0
            elif self.rect.right < 0:
                self.rect.left = WIDTH
            elif self.rect.bottom < 0:
                self.rect.top = HEIGHT
            elif self.rect.top > HEIGHT:
                self.rect.bottom = 0
            if self.difference_x > 0:
                self.animation_move_right.update(32, 32)
                self.moment_image = self.animation_move_right.moment_image
            if self.difference_x < 0:
                self.animation_move_left.update(32, 32)
                self.moment_image = self.animation_move_left.moment_image
            if self.difference_y < 0:
                self.animation_move_up.update(32, 32)
                self.moment_image = self.animation_move_up.moment_image
            if self.difference_y > 0:
                self.animation_move_down.update(32, 32)
                self.moment_image = self.animation_move_down.moment_image
            self.rect.x += self.difference_x
            self.rect.y += self.difference_y
        else:
            if self.animation_dead.moment_index == 10:
                self.animation_dead.moment_index = 11
            if self.animation_dead.moment_index < 11:
                self.animation_dead.update(30, 30)
            self.moment_image = self.animation_dead.moment_image

    def move_right(self):
        self.moment_image = self.const_image
        self.difference_y = 0
        self.difference_x = 3

    def move_left(self):
        self.moment_image = pygame.transform.rotate(self.const_image, 180)
        self.difference_y = 0
        self.difference_x = -3

    def move_up(self):
        self.moment_image = pygame.transform.rotate(self.const_image, 90)
        self.difference_x = 0
        self.difference_y = -3

    def move_down(self):
        self.moment_image = pygame.transform.rotate(self.const_image, 270)
        self.difference_x = 0
        self.difference_y = 3

    def stop_move_right(self):
        self.moment_image = self.const_image
        self.difference_x = 0

    def stop_move_left(self):
        self.moment_image = pygame.transform.rotate(self.const_image, 180)
        self.difference_x = 0

    def stop_move_up(self):
        self.moment_image = pygame.transform.rotate(self.const_image, 90)
        self.difference_y = 0

    def stop_move_down(self):
        self.moment_image = pygame.transform.rotate(self.const_image, 270)
        self.difference_y = 0


class Enemies(AbstractCreatures):
    def __init__(self, image, move_x, move_y, x, y):
        AbstractCreatures.__init__(self, image)
        self.end_game = False
        self.difference_y = move_y
        self.difference_x = move_x
        self.changing_points = []
        self.add_changing_points()
        self.image = self.const_image
        if move_x >= 0 and move_y == 0:
            self.direction = 'right'
        if move_x < 0 and move_y == 0:
            self.direction = 'left'
        if move_y >= 0 and move_x == 0:
            self.direction = 'down'
        if move_y < 0 and move_x == 0:
            self.direction = 'up'
        self.possible_directions = ['right', 'left', 'up', 'down']
        self.rect.center = (x, y)

    def add_changing_points(self):
        self.changing_points.append((WIDTH // 2, 20))
        self.changing_points.append((WIDTH // 2, HEIGHT // 2))
        self.changing_points.append((WIDTH - 20, HEIGHT // 2))
        self.changing_points.append((WIDTH - 20, 20))

    def update(self):
        self.change_direction()
        if self.rect.left > WIDTH:
            self.rect.right = 0
        elif self.rect.right < 0:
            self.rect.left = WIDTH
        elif self.rect.bottom < 0:
            self.rect.top = HEIGHT
        elif self.rect.top > HEIGHT:
            self.rect.bottom = 0
        if not self.end_game:
            if self.direction == 'right':
                self.move_right()
            elif self.direction == 'left':
                self.move_left()
            elif self.direction == 'down':
                self.move_down()
            elif self.direction == 'up':
                self.move_up()
        else:
            self.difference_x = 0
            self.difference_y = 0
        self.rect.x += self.difference_x
        self.rect.y += self.difference_y

    def change_direction(self):
        if self.rect.center in self.changing_points:
            if self.direction == 'right':
                self.possible_directions.remove('left')
                self.direction = random.choice(self.possible_directions)
                self.possible_directions.append('left')
            elif self.direction == 'left':
                self.possible_directions.remove('right')
                self.direction = random.choice(self.possible_directions)
                self.possible_directions.append('right')
            elif self.direction == 'up':
                self.possible_directions.remove('down')
                self.direction = random.choice(self.possible_directions)
                self.possible_directions.append('down')
            elif self.direction == 'down':
                self.possible_directions.remove('up')
                self.direction = random.choice(self.possible_directions)
                self.possible_directions.append('up')

    def move_right(self):
        self.image = self.const_image
        self.difference_y = 0
        self.difference_x = 2

    def move_left(self):
        self.image = pygame.transform.flip(self.const_image, True, False)
        self.difference_y = 0
        self.difference_x = -2

    def move_up(self):
        self.difference_x = 0
        self.difference_y = -2

    def move_down(self):
        self.difference_x = 0
        self.difference_y = 2
