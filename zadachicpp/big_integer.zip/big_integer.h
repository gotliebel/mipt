#include <stdexcept>
#pragma once

class BigIntegerOverflow : public std::runtime_error {
 public:
  BigIntegerOverflow() : std::runtime_error("BigIntegerOverflow") {
  }
};

class BigIntegerDivisionByZero : public std::runtime_error {
 public:
  BigIntegerDivisionByZero() : std::runtime_error("BigIntegerDivisionByZero") {
  }
};

class BigInteger {
  int array_[3400]{};
  static const int kKBase = 1e9;
  int size_ = 1;
  bool is_negative_ = false;

 public:
  BigInteger() = default;
  template <class T>
  BigInteger(T number) {  // NOLINT
    if (number < 0) {
      number = -number;
      is_negative_ = true;
    }
    size_ = 0;
    if (number == 0) {
      array_[size_] = 0;
      size_++;
    }
    while (number > 0) {
      array_[size_] = number % kKBase;
      size_++;
      number /= kKBase;
    }
  }
  BigInteger(const char* str);  // NOLINT
  BigInteger(char* str);        // NOLINT
  bool IsNegative();
  BigInteger Addition(BigInteger first, BigInteger second);
  BigInteger Subtraction(BigInteger first, BigInteger second);
  friend std::ostream& operator<<(std::ostream& os, const BigInteger& number);
  friend std::istream& operator>>(std::istream& is, BigInteger& number);
  friend BigInteger operator*(const BigInteger first, const BigInteger second);
  friend BigInteger operator-(const BigInteger first, const BigInteger second);
  friend BigInteger operator+(const BigInteger first, const BigInteger second);
  friend BigInteger operator+(const BigInteger& number);
  friend BigInteger operator-(const BigInteger& number);
  friend BigInteger& operator++(BigInteger& first);
  friend BigInteger& operator--(BigInteger& first);
  friend BigInteger operator++(BigInteger& first, int);
  friend BigInteger operator--(BigInteger& first, int);
  friend bool operator<(const BigInteger first, const BigInteger second);
  friend bool operator<=(const BigInteger first, const BigInteger second);
  friend bool operator>(const BigInteger first, const BigInteger second);
  friend bool operator>=(const BigInteger first, const BigInteger second);
  friend bool operator==(const BigInteger first, const BigInteger second);
  friend bool operator!=(const BigInteger first, const BigInteger second);
  friend BigInteger& operator+=(BigInteger& first, const BigInteger second);
  friend BigInteger& operator-=(BigInteger& first, const BigInteger second);
  friend BigInteger& operator*=(BigInteger& first, const BigInteger second);
};
