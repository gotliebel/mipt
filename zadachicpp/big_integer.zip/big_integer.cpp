#include "big_integer.h"
#include <cstring>
#include <cmath>
#include <iostream>

BigInteger::BigInteger(const char* str) {
  size_t length = strlen(str);
  size_t counter_digits = 0;
  size_t index = 0;
  for (int i = length - 1; i >= 0; --i) {
    if (counter_digits == 9) {
      index++;
      counter_digits = 0;
      size_++;
      if (size_ > 3000) {
        throw BigIntegerOverflow{};
      }
    }
    if (i == 0 && str[i] == '-') {
      is_negative_ = true;
      break;
    }
    if (i == 0 && str[i] == '+') {
      is_negative_ = false;
      break;
    }
    array_[index] += (str[i] - '0') * pow(10, counter_digits);
    counter_digits++;
  }
}
BigInteger::BigInteger(char* str) {
  size_t length = strlen(str);
  size_t counter_digits = 0;
  size_t index = 0;
  for (int i = length - 1; i >= 0; --i) {
    if (counter_digits == 9) {
      index++;
      counter_digits = 0;
      size_++;
      if (size_ > 3333) {
        throw BigIntegerOverflow{};
      }
    }
    if (i == 0 && str[i] == '-') {
      is_negative_ = true;
      break;
    }
    if (i == 0 && str[i] == '+') {
      is_negative_ = false;
      break;
    }
    array_[index] += (str[i] - '0') * pow(10, counter_digits);
    counter_digits++;
  }
}
std::ostream& operator<<(std::ostream& os, const BigInteger& number) {
  if (number.size_ == 1 && number.array_[0] == 0) {
    os << 0;
  } else {
    if (number.is_negative_) {
      os << '-';
    }
    os << number.array_[number.size_ - 1];
    for (int i = number.size_ - 2; i >= 0; --i) {
      int j = 0;
      for (; j < 10; ++j) {
        int degree_ten = pow(10, j);
        if (number.array_[i] / degree_ten == 0) {
          break;
        }
      }
      while ((9 - j) > 0) {
        os << '0';
        j++;
      }
      if (number.array_[i]) {
        os << number.array_[i];
      }
    }
  }
  return os;
}
std::istream& operator>>(std::istream& is, BigInteger& number) {
  const int k_size = 30001;
  char str[k_size]{};
  is >> str;
  number = BigInteger(str);
  return is;
}
BigInteger BigInteger::Addition(BigInteger first, BigInteger second) {
  size_ = std::max(first.size_, second.size_);
  int balance = 0;
  for (int i = 0; i < size_; ++i) {
    array_[i] += first.array_[i] + second.array_[i];
    balance = array_[i] / BigInteger::kKBase;
    if (balance) {
      array_[i + 1] = balance;
      array_[i] = array_[i] % BigInteger::kKBase;
    }
  }
  if (balance) {
    if (size_ + 1 > 3333) {
      throw BigIntegerOverflow{};
    }
    size_++;
  }
  return *this;
}
BigInteger operator+(BigInteger first, BigInteger second) {
  BigInteger final;
  if ((first.is_negative_ && second.is_negative_) || (!first.is_negative_ && !second.is_negative_)) {
    final.Addition(first, second);
    final.is_negative_ = first.is_negative_;
    return final;
  }
  if (first.is_negative_) {
    first.is_negative_ = false;
    if (first > second) {
      final.Subtraction(first, second);
      final.is_negative_ = true;
    } else if (first == second) {
      final.Subtraction(first, second);
    } else {
      final.Subtraction(second, first);
      final.is_negative_ = false;
    }
  } else {
    second.is_negative_ = false;
    if (second >= first) {
      final.Subtraction(second, first);
      final.is_negative_ = true;
    } else {
      final.Subtraction(first, second);
      final.is_negative_ = false;
    }
  }
  return final;
}
BigInteger BigInteger::Subtraction(BigInteger first, BigInteger second) {
  size_ = first.size_;
  for (int i = 0; i < first.size_; ++i) {
    array_[i] = first.array_[i] - second.array_[i];
    if (array_[i] < 0) {
      first.array_[i + 1]--;
      array_[i] += BigInteger::kKBase;
    }
  }
  for (int i = size_ - 1; i >= 0; --i) {
    if (array_[i] == 0) {
      size_--;
    } else {
      break;
    }
  }
  if (size_ == 0) {
    is_negative_ = false;
    size_ = 1;
  }
  return *this;
}
BigInteger operator-(BigInteger first, BigInteger second) {
  BigInteger final;
  if (!first.is_negative_ && !second.is_negative_) {
    if (first >= second) {
      final.Subtraction(first, second);
      final.is_negative_ = false;
    } else {
      final.Subtraction(second, first);
      final.is_negative_ = true;
    }
  } else if (first.is_negative_ && second.is_negative_) {
    if (first >= second) {
      final.Subtraction(second, first);
      final.is_negative_ = false;
    } else {
      final.Subtraction(first, second);
      final.is_negative_ = true;
    }
  } else if (first.is_negative_ && !second.is_negative_) {
    final.Addition(first, second);
    final.is_negative_ = true;
  } else {
    final.Addition(first, second);
    final.is_negative_ = false;
  }
  return final;
}
BigInteger operator*(BigInteger first, BigInteger second) {
  BigInteger final;
  for (int i = 0; i < first.size_; ++i) {
    int balance = 0;
    for (int j = 0; j < second.size_ || balance != 0; ++j) {
      if (i + j > 3333) {
        throw BigIntegerOverflow{};
      }
      int64_t tmp = final.array_[i + j] + balance + first.array_[i] * 1ll * (j < second.size_ ? second.array_[j] : 0);
      final.array_[i + j] = tmp % BigInteger::kKBase;
      balance = tmp / BigInteger::kKBase;
    }
  }
  int max_size = first.size_ + second.size_;
  while (max_size >= 0 && final.array_[max_size] == 0) {
    max_size--;
  }
  max_size++;
  if (!max_size) {
    final.is_negative_ = false;
    final.size_ = 1;
  } else {
    final.size_ = max_size;
    final.is_negative_ =
        !((first.is_negative_ && second.is_negative_) || (!first.is_negative_ && !second.is_negative_));
  }
  return final;
}
bool BigInteger::IsNegative() {
  return is_negative_;
}
BigInteger operator+(const BigInteger& number) {
  return number;
}
BigInteger operator-(const BigInteger& number) {
  BigInteger final;
  final.size_ = number.size_;
  for (int i = 0; i < number.size_; ++i) {
    final.array_[i] = number.array_[i];
  }
  final.is_negative_ = !number.is_negative_;
  return final;
}
bool operator<(BigInteger first, BigInteger second) {
  if (first.is_negative_ && !second.is_negative_) {
    return true;
  }
  if (!first.is_negative_ && second.is_negative_) {
    return false;
  }
  if (!first.is_negative_ && !second.is_negative_) {
    if (first.size_ < second.size_) {
      return true;
    }
    if (first.size_ > second.size_) {
      return false;
    }
    for (int i = first.size_ - 1; i >= 0; --i) {
      if (second.array_[i] > first.array_[i]) {
        return true;
      }
      if (second.array_[i] < first.array_[i]) {
        return false;
      }
    }
    return false;
  }
  if (first.size_ > second.size_) {
    return true;
  }
  if (first.size_ < second.size_) {
    return false;
  }
  for (int i = first.size_ - 1; i >= 0; --i) {
    if (second.array_[i] > first.array_[i]) {
      return false;
    }
    if (second.array_[i] < first.array_[i]) {
      return true;
    }
  }
  return false;
}
bool operator<=(BigInteger first, BigInteger second) {
  return first < second || first == second;
}
bool operator>(BigInteger first, BigInteger second) {
  return second < first;
}
bool operator>=(BigInteger first, BigInteger second) {
  return second < first || second == first;
}
bool operator==(BigInteger first, BigInteger second) {
  if (first.size_ == 1 && second.size_ == 1 && first.array_[0] == 0 && second.array_[0] == 0) {
    return true;
  }
  if (first.is_negative_ != second.is_negative_ || first.size_ != second.size_) {
    return false;
  }
  for (int i = 0; i < first.size_; ++i) {
    if (second.array_[i] > first.array_[i]) {
      return false;
    }
    if (second.array_[i] < first.array_[i]) {
      return false;
    }
  }
  return true;
}
bool operator!=(BigInteger first, BigInteger second) {
  return !(first == second);
}
BigInteger& operator++(BigInteger& first) {
  first += 1;
  if (first.size_ == 1 && first.array_[0] == 0) {
    first.is_negative_ = false;
  }
  return first;
}
BigInteger& operator--(BigInteger& first) {
  first -= 1;
  return first;
}
BigInteger operator++(BigInteger& first, int) {
  auto old = first;
  ++first;
  return old;
}
BigInteger operator--(BigInteger& first, int) {
  auto old = first;
  --first;
  return old;
}
BigInteger& operator+=(BigInteger& first, BigInteger second) {
  BigInteger final;
  final = first + second;
  first.is_negative_ = final.is_negative_;
  first.size_ = final.size_;
  for (int i = 0; i < final.size_; ++i) {
    first.array_[i] = final.array_[i];
  }
  return first;
}
BigInteger& operator-=(BigInteger& first, BigInteger second) {
  BigInteger final;
  final = first - second;
  first.is_negative_ = final.is_negative_;
  first.size_ = final.size_;
  for (int i = 0; i < final.size_; ++i) {
    first.array_[i] = final.array_[i];
  }
  return first;
}
BigInteger& operator*=(BigInteger& first, BigInteger second) {
  BigInteger final;
  final = first * second;
  first.is_negative_ = final.is_negative_;
  first.size_ = final.size_;
  for (int i = 0; i < final.size_; ++i) {
    first.array_[i] = final.array_[i];
  }
  return first;
}
