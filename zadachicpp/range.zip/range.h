#pragma once
#include <iterator>
#define REVERSE_RANGE_IMPLEMENTED

class RangeIterator {
 public:
  using iterator_category = std::bidirectional_iterator_tag;  // NOLINT
  using value_type = int64_t;                                 // NOLINT
  using difference_type = int64_t;                            // NOLINT
  using pointer = void;                                       // NOLINT
  using reference = int64_t;                                  // NOLINT
  explicit RangeIterator(int64_t state = 0, int64_t step = 1) : state_(state), step_(step){};
  RangeIterator& operator++() {
    state_ += step_;
    return *this;
  }
  RangeIterator operator++(int) {
    auto tmp = *this;
    state_ += step_;
    return tmp;
  }
  RangeIterator& operator--() {
    state_ += step_;
    return *this;
  }
  RangeIterator operator--(int) {
    auto tmp = *this;
    state_ += step_;
    return tmp;
  }
  reference operator[](const value_type& index) {
    return state_ + step_ * index;
  }
  value_type operator*() {
    return state_;
  }
  bool operator==(const RangeIterator& other) {
    return state_ == other.state_ && step_ == other.step_;
  }
  bool operator!=(const RangeIterator& other) {
    return !(*this == other);
  }

 private:
  value_type state_;
  value_type step_;
};

class Range {
 public:
  using iterator = RangeIterator;                                 // NOLINT
  using reverse_iterator = std::reverse_iterator<RangeIterator>;  // NOLINT
  using Value_type = RangeIterator::value_type;                   // NOLINT
  Range() : start_(0), end_(0), step_(1){};
  explicit Range(int64_t end) : start_(0), end_(end), step_(1) {
    if (end_ < 0) {
      end_ = 0;
    }
  };
  Range(int64_t start, int64_t end) : start_(start), end_(end), step_(1) {
    if (start_ > end_) {
      start_ = end_;
    }
  };
  Range(int64_t start, int64_t end, int64_t step) : start_(start), end_(end), step_(step) {
    if ((start_ > end_ && step_ > 0) || (end_ > start_ && step_ < 0) || step_ == 0) {
      start_ = end_;
      return;
    }
    if ((end_ - start_) % step_ != 0) {
      end_ += step_ - (end_ - start_) % step_;
    }
  }
  iterator begin() const {  // NOLINT
    return RangeIterator(start_, step_);
  }
  const iterator cbegin() const {  // NOLINT
    return RangeIterator(start_, step_);
  }
  iterator end() const {  // NOLINT
    return RangeIterator(end_, step_);
  }
  const iterator cend() const {  // NOLINT
    return RangeIterator(end_, step_);
  }
  reverse_iterator rbegin() const {  // NOLINT
    return std::make_reverse_iterator(RangeIterator(end_, -step_));
  }
  reverse_iterator rend() const {  // NOLINT
    return std::make_reverse_iterator(RangeIterator(start_, -step_));
  }

 private:
  Value_type start_;
  Value_type end_;
  Value_type step_;
};