#pragma once

#include <algorithm>
#include <forward_list>
#include <list>
#include <vector>

template <class KeyT>
class UnorderedSet {
 public:
  UnorderedSet() : buckets_(0), elements_(0), unordered_set_(){};
  explicit UnorderedSet(const size_t& count) : buckets_(count), elements_(0) {
    unordered_set_ = std::vector<std::list<KeyT>>(count);
  }
  UnorderedSet(typename std::forward_list<KeyT>::iterator begin, typename std::forward_list<KeyT>::iterator end) {
    elements_ = 0;
    buckets_ = 0;
    std::vector<KeyT> vector(begin, end);
    for (auto& value : vector) {
      Insert(value);
    }
  }
  UnorderedSet(const UnorderedSet<KeyT>& other) {
    elements_ = other.elements_;
    buckets_ = other.buckets_;
    unordered_set_ = other.unordered_set_;
  }
  UnorderedSet(UnorderedSet<KeyT>&& other) noexcept {
    elements_ = other.elements_;
    buckets_ = other.buckets_;
    unordered_set_ = std::move(other.unordered_set_);
    other.elements_ = 0;
    other.buckets_ = 0;
  }
  UnorderedSet& operator=(const UnorderedSet<KeyT>& other) {
    elements_ = other.elements_;
    buckets_ = other.buckets_;
    unordered_set_ = other.unordered_set_;
    return *this;
  }
  UnorderedSet& operator=(UnorderedSet<KeyT>&& other) noexcept {
    elements_ = other.elements_;
    buckets_ = other.buckets_;
    unordered_set_ = std::move(other.unordered_set_);
    other.elements_ = 0;
    other.buckets_ = 0;
    return *this;
  }
  size_t Size() const {
    return elements_;
  }
  bool Empty() const {
    return elements_ == 0;
  }
  void Clear() {
    elements_ = 0;
    buckets_ = 0;
    unordered_set_.clear();
  }
  void Insert(const KeyT& value) {
    if (elements_ >= buckets_) {
      if (buckets_ == 0) {
        Rehash(1);
      } else {
        Rehash(buckets_ * 2);
      }
    }
    if (!Find(value)) {
      size_t index_bucket = std::hash<KeyT>{}(value) % buckets_;
      unordered_set_[index_bucket].push_back(value);
      elements_++;
    }
  }
  void Insert(KeyT&& value) {
    if (elements_ >= buckets_) {
      if (buckets_ == 0) {
        Rehash(1);
      } else {
        Rehash(buckets_ * 2);
      }
    }
    if (!Find(value)) {
      size_t index_bucket = std::hash<KeyT>{}(value) % buckets_;
      unordered_set_[index_bucket].push_back(std::move(value));
      elements_++;
    }
  }
  void Erase(const KeyT& value) {
    if (Find(value)) {
      size_t index_bucket = std::hash<KeyT>{}(value) % buckets_;
      unordered_set_[index_bucket].erase(std::find_if(
          unordered_set_[index_bucket].begin(), unordered_set_[index_bucket].end(),
          [&value](const KeyT& comparing_value) { return std::equal_to<KeyT>{}(comparing_value, value); }));
      elements_--;
      if (elements_ * 2 < buckets_) {
        Rehash(elements_ * 2);
      }
    }
  }
  bool Find(const KeyT& value) const {
    if (Empty()) {
      return false;
    }
    size_t index_bucket = std::hash<KeyT>{}(value) % buckets_;
    return any_of(unordered_set_[index_bucket].begin(), unordered_set_[index_bucket].end(),
                  [&value](const KeyT& comparing_value) { return std::equal_to<KeyT>{}(value, comparing_value); });
  }
  void Rehash(const size_t& new_bucket_count) {
    if (new_bucket_count != buckets_ && new_bucket_count >= elements_) {
      std::vector<std::list<KeyT>> new_unordered_set(new_bucket_count);
      for (auto& bucket : unordered_set_) {
        for (auto& value : bucket) {
          size_t index_bucket = std::hash<KeyT>{}(value) % new_unordered_set.size();
          new_unordered_set[index_bucket].push_back(value);
        }
      }
      unordered_set_ = new_unordered_set;
      buckets_ = new_bucket_count;
    }
  }
  void Reserve(const size_t& new_bucket_count) {
    if (new_bucket_count > buckets_) {
      std::vector<std::list<KeyT>> new_unordered_set(new_bucket_count);
      for (auto& bucket : unordered_set_) {
        for (auto& value : bucket) {
          size_t index_bucket = std::hash<KeyT>{}(value) % new_unordered_set.size();
          new_unordered_set[index_bucket].push_back(value);
        }
      }
      unordered_set_ = new_unordered_set;
      buckets_ = new_bucket_count;
    }
  }
  size_t BucketCount() const {
    return buckets_;
  }
  size_t BucketSize(const size_t& id) const {
    if (id >= buckets_) {
      return 0;
    }
    return unordered_set_[id].size();
  }
  size_t Bucket(const KeyT& key) const {
    return std::hash<KeyT>{}(key) % buckets_;
  }
  double LoadFactor() const {
    if (buckets_ == 0) {
      return 0;
    }
    return static_cast<double>(elements_) / static_cast<double>(buckets_);
  }
  ~UnorderedSet() = default;

 private:
  size_t buckets_;
  size_t elements_;
  std::vector<std::list<KeyT>> unordered_set_;
};