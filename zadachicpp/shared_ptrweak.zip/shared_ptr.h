#include <stdexcept>
#include <iostream>
#define WEAK_PTR_IMPLEMENTED
#pragma once

class BadWeakPtr : public std::runtime_error {
 public:
  BadWeakPtr() : std::runtime_error("BadWeakPtr") {
  }
};

template <class T>
class WeakPtr;

struct Counter {
  int strong_counter = 0;
  int weak_counter = 0;
};

template <class T>
class SharedPtr {
  T* data_;
  Counter* counter_;

 public:
  SharedPtr() noexcept : data_(nullptr), counter_(nullptr){};
  explicit SharedPtr(T* data) : data_(data), counter_(nullptr) {
    if (data_ != nullptr) {
      counter_ = new Counter{1, 0};
    }
  }
  SharedPtr(const SharedPtr& other) : data_(other.data_), counter_(other.counter_) {
    if (other.data_ != nullptr) {
      ++(counter_->strong_counter);
    }
  }
  SharedPtr(std::nullptr_t) : data_(nullptr), counter_(nullptr){};                         // NOLINT
  SharedPtr(const WeakPtr<T>& other) : data_(other.Get()), counter_(other.GetCounter()) {  // NOLINT
    if (other.Expired()) {
      throw BadWeakPtr{};
    }
    ++(counter_->strong_counter);
  }
  void Swap(SharedPtr<T>& other) {
    std::swap(data_, other.data_);
    std::swap(counter_, other.counter_);
  }
  SharedPtr(SharedPtr&& other) noexcept : SharedPtr() {
    Swap(other);
  }
  SharedPtr& operator=(SharedPtr other) noexcept {
    Swap(other);
    return *this;
  }
  ~SharedPtr() {
    if (data_ == nullptr) {
      return;
    }
    --(counter_->strong_counter);
    if (counter_->strong_counter == 0) {
      delete data_;
      if (counter_->weak_counter == 0) {
        delete counter_;
      }
    }
  }
  void Reset(T* ptr = nullptr) {
    T* prev = data_;
    data_ = ptr;
    if (prev != nullptr) {
      --(counter_->strong_counter);
      if (counter_->strong_counter == 0) {
        delete prev;
        if (counter_->weak_counter == 0) {
          delete counter_;
        }
      }
    }
    counter_ = nullptr;
    if (data_ != nullptr) {
      counter_ = new Counter{1, 0};
    }
  }
  T* Get() const {
    return data_;
  }
  Counter* GetCounter() const {
    return counter_;
  }
  int UseCount() const {
    if (data_ == nullptr) {
      return 0;
    }
    return counter_->strong_counter;
  }
  T& operator*() const {
    return *data_;
  }
  T* operator->() const {
    return data_;
  }
  explicit operator bool() const {
    return data_ != nullptr;
  }
};

template <class T>
class WeakPtr {
  T* data_;
  Counter* counter_;

 public:
  WeakPtr() : data_(nullptr), counter_(nullptr){};
  WeakPtr(const WeakPtr& other) : data_(other.data_), counter_(other.counter_) {
    if (counter_ != nullptr) {
      ++(counter_->weak_counter);
    }
  }
  void Swap(WeakPtr<T>& other) {
    std::swap(data_, other.data_);
    std::swap(counter_, other.counter_);
  }
  WeakPtr(WeakPtr&& other) noexcept : WeakPtr() {
    Swap(other);
  }
  WeakPtr& operator=(WeakPtr other) noexcept {
    Swap(other);
    return *this;
  }
  WeakPtr(const SharedPtr<T>& other) : data_(other.Get()), counter_(other.GetCounter()) {  //  NOLINT
    if (counter_ != nullptr) {
      ++(counter_->weak_counter);
    }
  }
  ~WeakPtr() {
    if (counter_ != nullptr) {
      if (counter_->weak_counter > 0) {
        --(counter_->weak_counter);
      }
      if (counter_->weak_counter == 0 && counter_->strong_counter == 0) {
        delete counter_;
      }
    }
  }
  void Reset() {
    if (counter_ != nullptr) {
      if (counter_->weak_counter > 0) {
        --(counter_->weak_counter);
      }
      if (counter_->weak_counter == 0 && counter_->strong_counter == 0) {
        delete counter_;
      }
    }
    data_ = nullptr;
    counter_ = nullptr;
  }
  int UseCount() const {
    if (counter_ == nullptr) {
      return 0;
    }
    return counter_->strong_counter;
  }
  bool Expired() const {
    return (counter_ == nullptr || counter_->strong_counter == 0);
  }
  SharedPtr<T> Lock() const {
    if (Expired()) {
      return SharedPtr<T>();
    }
    return SharedPtr<T>(*this);
  }
  T* Get() const {
    return data_;
  }
  Counter* GetCounter() const {
    return counter_;
  }
};

template <class T, class... Args>
SharedPtr<T> MakeShared(Args&&... args) {
  return SharedPtr<T>(new T(std::forward<Args>(args)...));
}