#pragma once
#include <stdexcept>
#include <cstdint>

class ArrayOutOfRange : public std::out_of_range {
 public:
  ArrayOutOfRange() : std::out_of_range("ArrayOutOfRange") {
  }
};

template <class T, std::size_t N>
class Array {
 public:
  T array[N] = {};

 public:
  T& operator[](const int index) {
    return array[index];
  }
  T operator[](const int index) const {
    return array[index];
  }
  T& At(std::size_t index) {
    if (index >= N) {
      throw ArrayOutOfRange{};
    }
    return array[index];
  }
  T At(std::size_t index) const {
    if (index >= N) {
      throw ArrayOutOfRange{};
    }
    return array[index];
  }
  T Front() const {
    return array[0];
  }
  T& Front() {
    return array[0];
  }
  T Back() const {
    return array[N - 1];
  }
  T& Back() {
    return array[N - 1];
  }
  const T* Data() const {
    return array;
  }
  T Size() const {
    return N;
  }
  bool Empty() const {
    return N == 0;
  }
  void Fill(const T& value) {
    for (std::size_t i = 0; i < N; ++i) {
      array[i] = value;
    }
  }
  void Swap(Array<T, N>& other) {
    for (std::size_t i = 0; i < N; ++i) {
      T temp = array[i];
      array[i] = other[i];
      other[i] = temp;
    }
  }
};