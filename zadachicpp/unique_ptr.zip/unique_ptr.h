#ifndef OOP_ASSIGNMENTS_UNIQUE_PTR_H
#define OOP_ASSIGNMENTS_UNIQUE_PTR_H
#include <iostream>

template <class T>
class UniquePtr {
 public:
  UniquePtr() : ptr_(nullptr) {
  }
  explicit UniquePtr(T* ptr) : ptr_(ptr) {
  }
  ~UniquePtr() {
    delete ptr_;
  }
  UniquePtr(UniquePtr&& other) noexcept : ptr_(other.ptr_) {
    other.ptr_ = nullptr;
  }
  UniquePtr(UniquePtr& other) = delete;
  UniquePtr& operator=(UniquePtr& other) = delete;
  UniquePtr& operator=(UniquePtr&& other) noexcept {
    if (this != &other) {
      delete ptr_;
      ptr_ = other.ptr_;
      other.ptr_ = nullptr;
    }
    return *this;
  }
  T* Release() {
    auto other = ptr_;
    ptr_ = nullptr;
    return other;
  }
  void Swap(UniquePtr<T>& other) {
    auto tmp = ptr_;
    ptr_ = other.ptr_;
    other.ptr_ = tmp;
  }
  void Reset(T* ptr) {
    auto tmp = ptr_;
    ptr_ = ptr;
    delete tmp;
  }
  void Reset() {
    auto tmp = ptr_;
    ptr_ = nullptr;
    delete tmp;
  }
  T* Get() const {
    return ptr_;
  }
  T& operator*() const {
    return *ptr_;
  }
  T* operator->() const {
    return ptr_;
  }
  explicit operator bool() const {
    return this->ptr_;
  }

 private:
  T* ptr_;
};

#endif
