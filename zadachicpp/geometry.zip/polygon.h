#ifndef OOP_ASSIGNMENTS_POLYGON_H
#define OOP_ASSIGNMENTS_POLYGON_H
#pragma once

#include "ishape.h"
#include "point.h"
#include <vector>

namespace geometry {
class Polygon : public IShape {
 public:
  std::vector<Point> v_;
  Polygon() = default;
  explicit Polygon(const std::vector<Point>& v) {
    v_.resize(v.size());
    v_ = v;
  };
  Polygon& Move(const Vector&) override;
  bool ContainsPoint(const Point&) const override;
  bool CrossesSegment(const Segment&) const override;
  Polygon* Clone() const override;
  std::string ToString() const override;
};
}  // namespace geometry
#endif
