#ifndef OOP_ASSIGNMENTS_RAY_H
#define OOP_ASSIGNMENTS_RAY_H
#pragma once

#include "ishape.h"
#include "point.h"

namespace geometry {
class Ray : public IShape {
 public:
  Point point_;
  Vector vector_;
  Ray() = default;
  Ray(const Point& a, const Vector& ab) : point_(a), vector_(ab){};
  Ray(const Point& a, const Point& b) : point_(a) {
    vector_.v_x_ = static_cast<double>(b.x_ - a.x_);
    vector_.v_y_ = static_cast<double>(b.y_ - a.y_);
  }
  Ray& Move(const Vector&) override;
  bool ContainsPoint(const Point&) const override;
  bool CrossesSegment(const Segment&) const override;
  Ray* Clone() const override;
  std::string ToString() const override;
};
}  // namespace geometry
#endif
