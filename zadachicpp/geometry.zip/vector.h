#ifndef OOP_ASSIGNMENTS_VECTOR_H
#define OOP_ASSIGNMENTS_VECTOR_H
#pragma once

#include <iostream>
#include "ishape.h"

namespace geometry {
class Point;
class Vector {
 public:
  double v_x_;
  double v_y_;
  Vector() = default;
  Vector(const double& a, const double& b) : v_x_(a), v_y_(b){};
  Vector(const Point& a, const Point& b);
  Vector& operator+=(const Vector& vector);
  Vector& operator-=(const Vector& vector);
  Vector& operator*=(int64_t number);
  Vector& operator/=(int64_t number);
  bool operator==(const Vector vector);
  bool operator!=(const Vector vector);
  Vector operator+();
  Vector operator-();
};
}  // namespace geometry
#endif
