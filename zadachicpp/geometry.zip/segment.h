#ifndef OOP_ASSIGNMENTS_SEGMENT_H
#define OOP_ASSIGNMENTS_SEGMENT_H
#pragma once

#include "ishape.h"
#include "point.h"
#include "line.h"
#include "ray.h"

namespace geometry {
class Segment : public IShape {
 public:
  Point a_;
  Point b_;
  Segment() = default;
  Segment(const Point& a, const Point& b) : a_(a), b_(b){};
  Segment& Move(const Vector&) override;
  bool ContainsPoint(const Point&) const override;
  bool CrossesSegment(const Segment&) const override;
  Segment* Clone() const override;
  std::string ToString() const override;
  bool EndsAreOnDifferentSidesAndNonCollinear(const Segment& segment) const;
  bool IsCollinear(const Segment& segment) const;
  bool OnePointContains(const Segment& segment) const;
  bool CrossingSegments(const Segment& segment) const {
    if (EndsAreOnDifferentSidesAndNonCollinear(segment)) {
      return true;
    }
    if (IsCollinear(segment)) {
      return (OnePointContains(segment));
    }
    return false;
  }
};
double VectorMultiply(const Vector& first, const Vector& second);
double ScalarMultiply(const Vector& first, const Vector& second);
bool BelongsLine(const Line& line, const Point& point);
bool BelongsRay(const Ray& ray, const Point& point);
bool BelongsSegment(const Segment& segment, const Point& point);

}  // namespace geometry
#endif
