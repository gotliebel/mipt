#include "../line.h"
#include "../segment.h"
#include <iostream>

namespace geometry {
Line& Line::Move(const Vector& a) {
  first_.x_ += a.v_x_;
  first_.y_ += a.v_y_;
  second_.x_ += a.v_x_;
  second_.y_ += a.v_y_;
  return *this;
}

bool Line::ContainsPoint(const Point& a) const {
  return BelongsLine(*this, a);
}
bool CrossingLineSegment(const Line& line, const Segment& segment) {
  return VectorMultiply(Vector(line.first_, line.second_), Vector(line.first_, segment.b_)) *
             VectorMultiply(Vector(line.first_, line.second_), Vector(line.first_, segment.a_)) <=
         0;
}

bool Line::CrossesSegment(const Segment& segment) const {
  return CrossingLineSegment(*this, segment);
}
Line* Line::Clone() const {
  auto copy = new Line(first_, second_);
  return copy;
}
std::string Line::ToString() const {
  std::string str = "Line(";
  std::string str1 = std::to_string(second_.y_ - first_.y_);
  std::string str2 = std::to_string(-(second_.x_ - first_.x_));
  std::string str3 = std::to_string(-first_.x_ * (second_.y_ - first_.y_) + first_.y_ * (second_.x_ - first_.x_));
  str += str1;
  str += ", ";
  str += str2;
  str += ", ";
  str += str3;
  str += ")";
  return str;
}
}  // namespace geometry
