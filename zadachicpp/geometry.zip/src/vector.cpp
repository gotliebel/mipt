#include "../vector.h"
#include "../point.h"
#include <iostream>
namespace geometry {
Vector::Vector(const Point& a, const Point& b) {
  v_x_ = b.x_ - a.x_;
  v_y_ = b.y_ - a.y_;
}
Vector operator+(const Vector& first, const Vector& second) {
  Vector final;
  final.v_x_ = first.v_x_ + second.v_x_;
  final.v_y_ = first.v_y_ + second.v_y_;
  return final;
}
Vector operator-(const Vector& first, const Vector& second) {
  Vector final;
  final.v_x_ = second.v_x_ - first.v_x_;
  final.v_y_ = second.v_y_ - first.v_y_;
  return final;
}
Vector operator*(int64_t number, const Vector& vector) {
  Vector final;
  final.v_x_ = vector.v_x_ * number;
  final.v_y_ = vector.v_y_ * number;
  return final;
}
Vector operator/(const Vector& vector, int64_t number) {
  Vector final;
  final.v_x_ = vector.v_x_ / number;
  final.v_y_ = vector.v_y_ / number;
  return final;
}
Vector& Vector::operator+=(const Vector& vector) {
  v_x_ += vector.v_x_;
  v_y_ += vector.v_y_;
  return *this;
}
Vector& Vector::operator-=(const Vector& vector) {
  v_x_ -= vector.v_x_;
  v_y_ -= vector.v_y_;
  return *this;
}
Vector& Vector::operator*=(int64_t number) {
  v_x_ = v_x_ * number;
  v_y_ = v_y_ * number;
  return *this;
}
Vector& Vector::operator/=(int64_t number) {
  v_x_ = v_x_ / number;
  v_y_ = v_y_ / number;
  return *this;
}
bool Vector::operator==(const Vector vector) {
  return v_x_ == vector.v_x_ && v_y_ == vector.v_y_;
}
bool Vector::operator!=(const Vector vector) {
  return !(*this == vector);
}
Vector Vector::operator+() {
  return *this;
}
Vector Vector::operator-() {
  Vector final(v_x_, v_y_);
  final.v_x_ = -final.v_x_;
  final.v_y_ = -final.v_y_;
  return final;
}
}  // namespace geometry