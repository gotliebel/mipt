#include "../polygon.h"
#include "../segment.h"
#include <iostream>

namespace geometry {
Polygon& Polygon::Move(const Vector& ab) {
  int size = v_.size();
  for (int i = 0; i < size; ++i) {
    v_[i].x_ += ab.v_x_;
    v_[i].y_ += ab.v_y_;
  }
  return *this;
}
bool Polygon::ContainsPoint(const Point& check) const {
  int n = v_.size();
  const int max_coordinate = 100000000;
  Point largest_point(max_coordinate, check.y_ + 1);
  bool is_yes = false;
  int counter = 0;
  for (int i = 0; i < n - 1; ++i) {
    if (BelongsSegment(Segment(v_[i], v_[i + 1]), check)) {
      is_yes = true;
    }
    if (Segment(check, largest_point).CrossingSegments(Segment(v_[i], v_[i + 1]))) {
      counter++;
    }
  }
  if (Segment(check, largest_point).CrossingSegments(Segment(v_[n - 1], v_[0]))) {
    counter++;
  }
  if (is_yes) {
    return true;
  }
  return counter % 2 != 0;
}
bool Polygon::CrossesSegment(const Segment& ab) const {
  int n = v_.size();
  for (int i = 0; i < n - 1; ++i) {
    if (Segment(v_[i], v_[i + 1]).CrossingSegments(ab)) {
      return true;
    }
  }
  return Segment(v_[0], v_[n - 1]).CrossingSegments(ab);
}
Polygon* Polygon::Clone() const {
  auto copy = new Polygon(v_);
  return copy;
}
std::string Polygon::ToString() const {
  std::string str = "Polygon(";
  int n = v_.size();
  std::string str1;
  for (int i = 0; i < n; ++i) {
    str += "Point(";
    str1 = std::to_string(v_[i].x_);
    str += str1;
    str += ", ";
    str1 = std::to_string(v_[i].y_);
    str += str1;
    str += "), ";
  }
  str.pop_back();
  str.pop_back();
  str += ")";
  return str;
}
}  // namespace geometry
