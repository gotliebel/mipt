#include "../ray.h"
#include "../segment.h"
#include <iostream>

namespace geometry {
Ray& Ray::Move(const Vector& a) {
  point_.x_ += a.v_x_;
  point_.y_ += a.v_y_;
  return *this;
}
bool Ray::ContainsPoint(const Point& a) const {
  Point end;
  end.x_ = vector_.v_x_ + point_.x_;
  end.y_ = vector_.v_y_ + point_.y_;
  if (end == point_) {
    return end == a;
  }
  return BelongsRay(Ray(point_, end), a);
}
bool Ray::CrossesSegment(const Segment& ab) const {
  Point tmp;
  tmp.x_ = vector_.v_x_ + point_.x_;
  tmp.y_ = vector_.v_y_ + point_.y_;
  if (vector_.v_y_ == 0 && vector_.v_x_ == 0 && !(ab.a_ == ab.b_)) {
    return BelongsSegment(ab, point_);
  }
  if (vector_.v_y_ == 0 && vector_.v_x_ == 0 && ab.a_ == ab.b_) {
    return ab.a_ == point_;
  }
  if (BelongsSegment(ab, point_)) {
    return true;
  }
  return (VectorMultiply(Vector(ab.a_, point_), Vector(ab.a_, ab.b_)) *
              VectorMultiply(Vector(point_, tmp), Vector(ab.a_, ab.b_)) <=
          0);
}
Ray* Ray::Clone() const {
  auto copy = new Ray(point_, vector_);
  return copy;
}
std::string Ray::ToString() const {
  std::string str = "Ray(Point(";
  std::string str1 = std::to_string(point_.x_);
  str += str1;
  str += ", ";
  str1 = std::to_string(point_.y_);
  str += str1;
  str += "), Vector(";
  str1 = std::to_string(static_cast<int>(vector_.v_x_));
  str += str1;
  str += ", ";
  str1 = std::to_string(static_cast<int>(vector_.v_y_));
  str += str1;
  str += "))";
  return str;
}
}  // namespace geometry