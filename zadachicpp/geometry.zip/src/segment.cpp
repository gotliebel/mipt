#include "../segment.h"
#include <iostream>

namespace geometry {
double VectorMultiply(const Vector& first, const Vector& second) {
  return first.v_x_ * second.v_y_ - first.v_y_ * second.v_x_;
}
double ScalarMultiply(const Vector& first, const Vector& second) {
  return first.v_x_ * second.v_x_ + first.v_y_ * second.v_y_;
}
bool BelongsLine(const Line& line, const Point& point) {
  return point.x_ * (line.second_.y_ - line.first_.y_) - line.first_.x_ * (line.second_.y_ - line.first_.y_) -
             point.y_ * (line.second_.x_ - line.first_.x_) + line.first_.y_ * (line.second_.x_ - line.first_.x_) ==
         0;
}
bool BelongsRay(const Ray& ray, const Point& point) {
  Point first = ray.point_;
  Point second = {ray.point_.x_ + static_cast<int64_t>(ray.vector_.v_x_),
                  ray.point_.y_ + static_cast<int64_t>(ray.vector_.v_y_)};
  return (BelongsLine(Line(first, second), point) &&
          ((first.x_ - point.x_) * (second.x_ - first.x_) + (first.y_ - point.y_) * (second.y_ - first.y_) <= 0));
}
bool BelongsSegment(const Segment& segment, const Point& point) {
  return (BelongsRay(Ray(segment.a_, segment.b_), point) &&
          (segment.b_.x_ - point.x_) * (segment.b_.x_ - segment.a_.x_) +
                  (segment.b_.y_ - point.y_) * (segment.b_.y_ - segment.a_.y_) >=
              0);
}
bool Segment::EndsAreOnDifferentSidesAndNonCollinear(const Segment& segment) const {
  return (VectorMultiply(Vector(a_, b_), Vector(a_, segment.b_)) *
                  VectorMultiply(Vector(a_, b_), Vector(a_, segment.a_)) <
              0 &&
          VectorMultiply(Vector(segment.a_, segment.b_), Vector(segment.a_, a_)) *
                  VectorMultiply(Vector(segment.a_, segment.b_), Vector(segment.a_, b_)) <
              0);
}
bool Segment::IsCollinear(const Segment& segment) const {
  return (VectorMultiply(Vector(a_, b_), Vector(a_, segment.b_)) *
                  VectorMultiply(Vector(a_, b_), Vector(a_, segment.a_)) ==
              0 ||
          VectorMultiply(Vector(segment.a_, segment.b_), Vector(segment.a_, a_)) *
                  VectorMultiply(Vector(segment.a_, segment.b_), Vector(segment.a_, b_)) ==
              0);
}
bool Segment::OnePointContains(const Segment& segment) const {
  return ((VectorMultiply(Vector(a_, b_), Vector(a_, segment.a_)) == 0 &&
           ScalarMultiply(Vector(segment.a_, a_), Vector(segment.a_, b_)) <= 0) ||
          (VectorMultiply(Vector(a_, b_), Vector(a_, segment.b_)) == 0 &&
           ScalarMultiply(Vector(segment.b_, a_), Vector(segment.b_, b_)) <= 0) ||
          (VectorMultiply(Vector(segment.a_, segment.b_), Vector(a_, segment.b_)) == 0 &&
           ScalarMultiply(Vector(a_, segment.a_), Vector(a_, segment.b_)) <= 0) ||
          (VectorMultiply(Vector(segment.a_, segment.b_), Vector(segment.a_, b_)) == 0 &&
           ScalarMultiply(Vector(b_, segment.a_), Vector(b_, segment.b_)) <= 0));
}
Segment& Segment::Move(const Vector& ab) {
  a_.Move(ab);
  b_.Move(ab);
  return *this;
}
bool Segment::ContainsPoint(const Point& a) const {
  if (a_ == b_) {
    return a_ == a;
  }
  return BelongsSegment(*this, a);
}
bool Segment::CrossesSegment(const Segment& ab) const {
  if (a_ == b_ && !(ab.a_ == ab.b_)) {
    return BelongsSegment(ab, a_);
  }
  if (!(a_ == b_) && ab.a_ == ab.b_) {
    return BelongsSegment(*this, ab.a_);
  }
  if (a_ == b_ && ab.a_ == ab.b_) {
    return a_ == ab.a_;
  }
  return CrossingSegments(ab);
}
Segment* Segment::Clone() const {
  auto copy = new Segment(a_, b_);
  return copy;
}
std::string Segment::ToString() const {
  std::string str = "Segment(Point(";
  std::string str1 = std::to_string(a_.x_);
  str += str1;
  str += ", ";
  str1 = std::to_string(a_.y_);
  str += str1;
  str += "), Point(";
  str1 = std::to_string(b_.x_);
  str += str1;
  str += ", ";
  str1 = std::to_string(b_.y_);
  str += str1;
  str += "))";
  return str;
}
}  // namespace geometry