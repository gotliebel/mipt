#include "../circle.h"
#include "../segment.h"
#include <iostream>
#include <cmath>

namespace geometry {
Circle& Circle::Move(const Vector& a) {
  center_.x_ += a.v_x_;
  center_.y_ += a.v_y_;
  return *this;
}
bool Circle::ContainsPoint(const Point& a) const {
  return (sqrt((center_.x_ - a.x_) * (center_.x_ - a.x_) + (center_.y_ - a.y_) * (center_.y_ - a.y_)) <= radius_);
}
double DistanceSegment(const Segment& segment, const Point& point) {
  if (((point.x_ - segment.a_.x_) * (segment.b_.x_ - segment.a_.x_) +
           (point.y_ - segment.a_.y_) * (segment.b_.y_ - segment.a_.y_) >=
       0) &&
      ((point.x_ - segment.b_.x_) * (segment.a_.x_ - segment.b_.x_) +
       (point.y_ - segment.b_.y_) * (segment.a_.y_ - segment.b_.y_)) >= 0) {
    return std::abs((segment.b_.x_ - segment.a_.x_) * (point.y_ - segment.a_.y_) -
                    (segment.b_.y_ - segment.a_.y_) * (point.x_ - segment.a_.x_)) /
           sqrt((segment.b_.x_ - segment.a_.x_) * (segment.b_.x_ - segment.a_.x_) +
                (segment.b_.y_ - segment.a_.y_) * (segment.b_.y_ - segment.a_.y_));
  }
  return sqrt(std::min(
      (point.x_ - segment.a_.x_) * (point.x_ - segment.a_.x_) + (point.y_ - segment.a_.y_) * (point.y_ - segment.a_.y_),
      (point.x_ - segment.b_.x_) * (point.x_ - segment.b_.x_) +
          (point.y_ - segment.b_.y_) * (point.y_ - segment.b_.y_)));
}

bool Circle::CrossesSegment(const Segment& a) const {
  if (DistanceSegment(a, center_) <= radius_) {
    return (sqrt((center_.x_ - a.a_.x_) * (center_.x_ - a.a_.x_) + (center_.y_ - a.a_.y_) * (center_.y_ - a.a_.y_)) >=
                radius_ ||
            sqrt((center_.x_ - a.b_.x_) * (center_.x_ - a.b_.x_) + (center_.y_ - a.b_.y_) * (center_.y_ - a.b_.y_)) >=
                radius_);
  }
  return false;
}
Circle* Circle::Clone() const {
  auto copy = new Circle(center_, radius_);
  return copy;
}
std::string Circle::ToString() const {
  std::string str = "Circle(Point(";
  std::string str1 = std::to_string(center_.x_);
  str += str1;
  str += ", ";
  str1 = std::to_string(center_.y_);
  str += str1;
  str += "), ";
  str1 = std::to_string(radius_);
  str += str1;
  str += ")";
  return str;
}
}  // namespace geometry