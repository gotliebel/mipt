#ifndef OOP_ASSIGNMENTS_CIRCLE_H
#define OOP_ASSIGNMENTS_CIRCLE_H
#pragma once

#include "ishape.h"
#include "point.h"

namespace geometry {
class Circle : public IShape {
 public:
  Point center_;
  int64_t radius_;
  Circle() = default;
  Circle(const Point& a, const int64_t& rad) : center_(a), radius_(rad){};
  Circle& Move(const Vector&) override;
  bool ContainsPoint(const Point&) const override;
  bool CrossesSegment(const Segment&) const override;
  Circle* Clone() const override;
  std::string ToString() const override;
};
}  // namespace geometry
#endif
