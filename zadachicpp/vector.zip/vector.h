#pragma once

template <class T>
class Vector {
 public:
  using ValueType = T;
  using Pointer = T*;
  using ConstPointer = T*;
  using Reference = T&;
  using ConstReference = const T&;
  using SizeType = size_t;
  using Iterator = T*;
  using ConstIterator = const T*;
  using ReverseIterator = std::reverse_iterator<T*>;
  using ConstReverseIterator = std::reverse_iterator<const T*>;
  Iterator begin() noexcept {  // NOLINT
    return vector_;
  }
  ConstIterator begin() const noexcept {  // NOLINT
    return vector_;
  }
  ConstIterator cbegin() const noexcept {  // NOLINT
    return vector_;
  }
  Iterator end() noexcept {  // NOLINT
    return vector_ + size_;
  }
  ConstIterator end() const noexcept {  // NOLINT
    return vector_ + size_;
  }
  ConstIterator cend() const noexcept {  // NOLINT
    return vector_ + size_;
  }
  ReverseIterator rbegin() noexcept {  // NOLINT
    return std::make_reverse_iterator(vector_ + size_);
  }
  ConstReverseIterator rbegin() const noexcept {  // NOLINT
    return std::make_reverse_iterator(vector_ + size_);
  }
  ConstReverseIterator crbegin() const noexcept {  // NOLINT
    return std::make_reverse_iterator(vector_ + size_);
  }
  ReverseIterator rend() noexcept {  // NOLINT
    return std::make_reverse_iterator(vector_);
  }
  ConstReverseIterator rend() const noexcept {  // NOLINT
    return std::make_reverse_iterator(vector_);
  }
  ConstReverseIterator crend() noexcept {  // NOLINT
    return std::make_reverse_iterator(vector_);
  }
  Vector() : vector_(nullptr), size_(0), capacity_(0){};
  explicit Vector(const size_t& size) : size_(size), capacity_(size) {
    if (size == 0) {
      vector_ = nullptr;
    } else {
      vector_ = new T[size]();
    }
  }
  Vector(const size_t& size, const T& value) : Vector(size) {
    for (size_t i = 0; i < size; ++i) {
      vector_[i] = value;
    }
  }
  Vector(const Vector<T>& other) {
    if (other.vector_ != nullptr) {
      auto new_vector = new T[other.capacity_];
      try {
        for (size_t i = 0; i < other.size_; ++i) {
          new_vector[i] = other.vector_[i];
        }
      } catch (...) {
        delete[] new_vector;
        throw;
      }
      vector_ = new_vector;
      size_ = other.size_;
      capacity_ = other.capacity_;
    } else {
      vector_ = nullptr;
      size_ = 0;
      capacity_ = 0;
    }
  }
  template <class Iterator, class = std::enable_if_t<std::is_base_of_v<
                                std::forward_iterator_tag, typename std::iterator_traits<Iterator>::iterator_category>>>
  Vector(Iterator first, Iterator second) {
    size_t tmp = second - first;
    if (tmp == 0) {
      vector_ = nullptr;
      size_ = 0;
      capacity_ = 0;
    } else {
      auto new_vector = new T[tmp];
      try {
        for (size_t i = 0; i < tmp; ++i, ++first) {
          new_vector[i] = *first;
        }
      } catch (...) {
        vector_ = nullptr;
        size_ = 0;
        capacity_ = 0;
      }
      vector_ = new_vector;
      capacity_ = tmp;
      size_ = tmp;
    }
  }
  Vector(Vector<T>&& other) noexcept {
    size_ = other.size_;
    capacity_ = other.capacity_;
    vector_ = other.vector_;
    other.vector_ = nullptr;
    other.size_ = 0;
    other.capacity_ = 0;
  }

  Vector(std::initializer_list<T> list) : Vector(list.size()) {
    int index = 0;
    for (const auto& i : list) {
      vector_[index] = i;
      ++index;
    }
  }
  Vector<T>& operator=(const Vector<T>& other) {
    if (this != &other) {
      Vector<T>(other).Swap(*this);
    }
    return *this;
  }
  Vector<T>& operator=(Vector<T>&& other) noexcept {
    if (this != &other) {
      Vector<T>(std::move(other)).Swap(*this);
    }
    return *this;
  }
  size_t Size() const {
    return size_;
  }
  size_t Capacity() const {
    return capacity_;
  }
  bool Empty() const {
    return size_ == 0;
  };
  const T& operator[](const size_t& index) const {
    return vector_[index];
  }
  T& operator[](const size_t& index) {
    return vector_[index];
  }
  const T& At(const size_t& index) const {
    if (index >= size_ || index < 0) {
      throw std::out_of_range("out of range");
    }
    return vector_[index];
  }
  T& At(const size_t& index) {
    if (index >= size_ || index < 0) {
      throw std::out_of_range("out of range");
    }
    return vector_[index];
  }
  const T& Front() const {
    return vector_[0];
  }
  T& Front() {
    return vector_[0];
  }
  const T& Back() const {
    return vector_[size_ - 1];
  }
  T& Back() {
    return vector_[size_ - 1];
  }
  T* Data() const {
    return vector_;
  }
  void Swap(Vector<T>& other) {
    std::swap(vector_, other.vector_);
    std::swap(size_, other.size_);
    std::swap(capacity_, other.capacity_);
  }
  void Resize(const size_t& new_size) {
    if (capacity_ < new_size) {
      auto new_vector = new T[new_size];
      try {
        for (size_t i = 0; i < size_; ++i) {
          new_vector[i] = std::move(vector_[i]);
        }
      } catch (...) {
        delete[] new_vector;
        throw;
      }
      delete[] vector_;
      vector_ = new_vector;
      size_ = new_size;
      capacity_ = new_size;
    } else {
      size_ = new_size;
    }
  }
  void Resize(const size_t& new_size, const T& value) {
    if (capacity_ < new_size) {
      auto new_vector = new T[new_size];
      try {
        for (size_t i = 0; i < size_; ++i) {
          new_vector[i] = std::move(vector_[i]);
        }
        for (size_t i = size_; i < new_size; ++i) {
          new_vector[i] = value;
        }
      } catch (...) {
        delete[] new_vector;
        throw;
      }
      delete[] vector_;
      vector_ = new_vector;
      size_ = new_size;
      capacity_ = new_size;
    } else {
      for (size_t i = size_; i < new_size; ++i) {
        vector_[i] = value;
      }
      size_ = new_size;
    }
  }
  void Reserve(const size_t& new_cap) {
    if (new_cap > 0) {
      if (new_cap > capacity_) {
        auto new_vector = new T[new_cap];
        try {
          for (size_t i = 0; i < size_; ++i) {
            new_vector[i] = std::move(vector_[i]);
          }
        } catch (...) {
          delete[] new_vector;
          throw;
        }
        delete[] vector_;
        vector_ = new_vector;
        capacity_ = new_cap;
      }
    }
  }
  void ShrinkToFit() {
    if (capacity_ > size_) {
      if (Empty()) {
        delete[] vector_;
        vector_ = nullptr;
        capacity_ = 0;
      } else {
        auto new_vector = new T[size_];
        try {
          for (size_t i = 0; i < size_; ++i) {
            new_vector[i] = std::move(vector_[i]);
          }
        } catch (...) {
          delete[] new_vector;
          throw;
        }
        delete[] vector_;
        vector_ = new_vector;
        capacity_ = size_;
      }
    }
  }
  void Clear() {
    size_ = 0;
  }
  void PushBack(T&& value) {
    if (capacity_ == 0) {
      vector_ = new T[capacity_ + 1];
      try {
        vector_[0] = std::move(value);
      } catch (...) {
        delete[] vector_;
        vector_ = nullptr;
      }
      size_++;
      capacity_++;
    } else if (capacity_ == size_) {
      size_t tmp_capacity = capacity_ * 2;
      auto new_vector = new T[tmp_capacity];
      try {
        for (size_t i = 0; i < size_; ++i) {
          new_vector[i] = std::move(vector_[i]);
        }
      } catch (...) {
        delete[] new_vector;
        throw;
      }
      try {
        new_vector[size_] = std::move(value);
      } catch (...) {
        delete[] new_vector;
        throw;
      }
      delete[] vector_;
      vector_ = new_vector;
      capacity_ = tmp_capacity;
      size_++;
    } else {
      try {
        vector_[size_] = std::move(value);
      } catch (...) {
        throw;
      }
      size_++;
    }
  }
  void PushBack(const T& value) {
    if (capacity_ == 0) {
      vector_ = new T[capacity_ + 1];
      try {
        vector_[0] = std::move(value);
      } catch (...) {
        delete[] vector_;
        vector_ = nullptr;
      }
      size_++;
      capacity_++;
    } else if (capacity_ == size_) {
      size_t tmp_capacity = capacity_ * 2;
      auto new_vector = new T[tmp_capacity];
      try {
        for (size_t i = 0; i < size_; ++i) {
          new_vector[i] = std::move(vector_[i]);
        }
      } catch (...) {
        delete[] new_vector;
        throw;
      }
      try {
        new_vector[size_] = std::move(value);
      } catch (...) {
        delete[] new_vector;
        throw;
      }
      delete[] vector_;
      vector_ = new_vector;
      capacity_ = tmp_capacity;
      size_++;
    } else {
      try {
        vector_[size_] = std::move(value);
      } catch (...) {
        throw;
      }
      size_++;
    }
  }

  void PopBack() {
    if (size_ != 0) {
      size_--;
    }
  }
  friend bool operator<(const Vector<T>& first, const Vector<T>& second) {
    size_t min_size = std::min(first.size_, second.size_);
    size_t index = 0;
    while (index < min_size && first.vector_[index] == second.vector_[index]) {
      index++;
    }
    if (index == min_size) {
      return first.size_ < second.size_;
    }
    return first.vector_[index] < second.vector_[index];
  }
  friend bool operator>(const Vector<T>& first, const Vector<T>& second) {
    return second < first;
  }
  friend bool operator<=(const Vector<T>& first, const Vector<T>& second) {
    return first < second || first == second;
  }
  friend bool operator>=(const Vector<T>& first, const Vector<T>& second) {
    return first > second || first == second;
  }
  friend bool operator==(const Vector<T>& first, const Vector<T>& second) {
    return !(first < second) && !(first > second);
  }
  friend bool operator!=(const Vector<T>& first, const Vector<T>& second) {
    return !(first == second);
  }
  ~Vector() {
    delete[] vector_;
    size_ = 0;
    capacity_ = 0;
  }

 private:
  T* vector_;
  size_t size_;
  size_t capacity_;
};