#pragma once

template <class T>
class Reversed {
 public:
  Reversed() = default;
  explicit Reversed(T& container) : buffer_(&container){};
  auto begin() const {  // NOLINT
    return std::make_reverse_iterator(buffer_->end());
  }
  auto end() const {  // NOLINT
    return std::make_reverse_iterator(buffer_->begin());
  }
  auto begin() {  // NOLINT
    return std::make_reverse_iterator(buffer_->end());
  }
  auto end() {  // NOLINT
    return std::make_reverse_iterator(buffer_->begin());
  }

 private:
  T* buffer_;
};