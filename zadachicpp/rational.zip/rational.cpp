#include <cstring>
#include <iostream>
#include <numeric>
#include "rational.h"

Rational::Rational() {
  numerator_ = 0;
  denominator_ = 1;
}

Rational::Rational(int32_t numerator) {
  numerator_ = numerator;
  denominator_ = 1;
}

void Rational::ShortFrac(int32_t& numerator, int32_t& denominator) {
  int32_t gcd = std::gcd(numerator, denominator);
  numerator = numerator / gcd;
  denominator = denominator / gcd;
  if (numerator * denominator < 0) {
    if (denominator < 0) {
      denominator = -denominator;
      numerator = -numerator;
    }
  } else {
    if (denominator < 0) {
      denominator = -denominator;
      numerator = -numerator;
    }
  }
}

Rational::Rational(int32_t numerator, int32_t denominator) {
  if (denominator == 0) {
    throw RationalDivisionByZero{};
  }
  if (numerator == 0) {
    numerator_ = 0;
    denominator_ = 1;
  } else {
    ShortFrac(numerator, denominator);
    numerator_ = numerator;
    denominator_ = denominator;
  }
}

int32_t Rational::GetNumerator() const {
  return numerator_;
}
int32_t Rational::GetDenominator() const {
  return denominator_;
}
void Rational::SetNumerator(int32_t numerator) {
  if (denominator_ == 0) {
    throw RationalDivisionByZero{};
  }
  ShortFrac(numerator, denominator_);
  numerator_ = numerator;
}
void Rational::SetDenominator(int32_t denominator) {
  if (denominator == 0) {
    throw RationalDivisionByZero{};
  }
  ShortFrac(numerator_, denominator);
  denominator_ = denominator;
}
Rational operator+(Rational first, Rational second) {
  Rational final;
  final.numerator_ = first.numerator_ * second.denominator_ + second.numerator_ * first.denominator_;
  final.denominator_ = first.denominator_ * second.denominator_;
  if (final.numerator_ == 0) {
    final.denominator_ = 1;
    return final;
  }
  final.ShortFrac(final.numerator_, final.denominator_);
  return final;
}
Rational operator-(Rational first, Rational second) {
  Rational final;
  final.numerator_ = first.numerator_ * second.denominator_ - second.numerator_ * first.denominator_;
  final.denominator_ = first.denominator_ * second.denominator_;
  if (final.numerator_ == 0) {
    final.denominator_ = 1;
    return final;
  }
  final.ShortFrac(final.numerator_, final.denominator_);
  return final;
}
Rational operator/(Rational first, Rational second) {
  if (second.numerator_ == 0) {
    throw RationalDivisionByZero{};
  }
  Rational final;
  final.numerator_ = first.numerator_ * second.denominator_;
  final.denominator_ = first.denominator_ * second.numerator_;
  if (final.numerator_ == 0) {
    final.denominator_ = 1;
    return final;
  }
  final.ShortFrac(final.numerator_, final.denominator_);
  return final;
}
Rational operator*(Rational first, Rational second) {
  Rational final;
  final.numerator_ = first.numerator_ * second.numerator_;
  final.denominator_ = first.denominator_ * second.denominator_;
  if (final.numerator_ == 0) {
    final.denominator_ = 1;
    return final;
  }
  final.ShortFrac(final.numerator_, final.denominator_);
  return final;
}
Rational& operator+=(Rational& first, Rational second) {
  first.numerator_ = first.numerator_ * second.denominator_ + second.numerator_ * first.denominator_;
  first.denominator_ = first.denominator_ * second.denominator_;
  if (first.numerator_ == 0) {
    first.denominator_ = 1;
    return first;
  }
  first.ShortFrac(first.numerator_, first.denominator_);
  return first;
}
Rational& operator-=(Rational& first, Rational second) {
  first.numerator_ = first.numerator_ * second.denominator_ - second.numerator_ * first.denominator_;
  first.denominator_ = first.denominator_ * second.denominator_;
  if (first.numerator_ == 0) {
    first.denominator_ = 1;
    return first;
  }
  first.ShortFrac(first.numerator_, first.denominator_);
  return first;
}
Rational& operator*=(Rational& first, Rational second) {
  first.numerator_ = first.numerator_ * second.numerator_;
  first.denominator_ = first.denominator_ * second.denominator_;
  if (first.numerator_ == 0) {
    first.denominator_ = 1;
    return first;
  }
  first.ShortFrac(first.numerator_, first.denominator_);
  return first;
}
Rational& operator/=(Rational& first, Rational second) {
  if (second.numerator_ == 0) {
    throw RationalDivisionByZero{};
  }
  first.numerator_ = first.numerator_ * second.denominator_;
  first.denominator_ = first.denominator_ * second.numerator_;
  first.ShortFrac(first.numerator_, first.denominator_);
  return first;
}
Rational operator+(const Rational& first) {
  return first;
}
Rational operator-(const Rational& first) {
  Rational final;
  final.numerator_ = -first.numerator_;
  final.denominator_ = first.denominator_;
  return final;
}
bool operator<(Rational first, Rational second) {
  Rational final = first - second;
  return final.numerator_ < 0;
}
bool operator>(Rational first, Rational second) {
  Rational final = first - second;
  return final.numerator_ > 0;
}
bool operator<=(Rational first, Rational second) {
  Rational final = first - second;
  return final.numerator_ <= 0;
}
bool operator>=(Rational first, Rational second) {
  Rational final = first - second;
  return final.numerator_ >= 0;
}
bool operator==(Rational first, Rational second) {
  Rational final = first - second;
  return final.numerator_ == 0;
}
bool operator!=(Rational first, Rational second) {
  Rational final = first - second;
  return final.numerator_ != 0;
}
Rational& operator++(Rational& first) {
  first.numerator_ = first.numerator_ + first.denominator_;
  if (first.numerator_ == 0) {
    first.denominator_ = 1;
    return first;
  }
  first.ShortFrac(first.numerator_, first.denominator_);
  return first;
}
Rational& operator--(Rational& first) {
  first.numerator_ = first.numerator_ - first.denominator_;
  if (first.numerator_ == 0) {
    first.denominator_ = 1;
    return first;
  }
  first.ShortFrac(first.numerator_, first.denominator_);
  return first;
}
Rational operator++(Rational& first, int) {
  Rational old = first;
  ++first;
  return old;
}
Rational operator--(Rational& first, int) {
  Rational old = first;
  --first;
  return old;
}
std::istream& operator>>(std::istream& is, Rational& value) {
  value.numerator_ = 0;
  value.denominator_ = 0;
  auto str = new char[100];
  is >> str;
  bool first_minus = false;
  size_t index_first = 0;
  if (str[index_first] == '-') {
    first_minus = true;
    index_first++;
  }
  size_t len = strlen(str);
  auto str_num = new char[100];
  auto str_den = new char[100];
  size_t index_second = 0;
  while (str[index_first] != '/' && index_first < len + 1) {
    str_num[index_second] = str[index_first];
    index_first++;
    index_second++;
  }
  index_first++;
  bool is_nat = true;
  if (index_first < len) {
    is_nat = false;
    index_second = 0;
    if (str[index_first] == '-' && first_minus) {
      first_minus = false;
      index_first++;
    } else if (str[index_first] == '-' && !first_minus) {
      first_minus = true;
      index_first++;
    }
    while (index_first < len) {
      str_den[index_second] = str[index_first];
      index_first++;
      index_second++;
    }
  }
  if (is_nat) {
    if (first_minus) {
      value.numerator_ = -std::atoi(str_num);
      value.denominator_ = 1;
    } else {
      value.numerator_ = std::atoi(str_num);
      value.denominator_ = 1;
    }
  } else {
    if (std::atoi(str_den) == 0) {
      delete[] str;
      delete[] str_num;
      delete[] str_den;
      throw RationalDivisionByZero{};
    }
    if (!first_minus) {
      value.numerator_ = std::atoi(str_num);
      value.denominator_ = std::atoi(str_den);
      value.ShortFrac(value.numerator_, value.denominator_);
    } else {
      value.numerator_ = -std::atoi(str_num);
      value.denominator_ = std::atoi(str_den);
      value.ShortFrac(value.numerator_, value.denominator_);
    }
  }
  delete[] str;
  delete[] str_num;
  delete[] str_den;
  return is;
}
std::ostream& operator<<(std::ostream& os, const Rational& first) {
  if (first.denominator_ == 1) {
    os << first.numerator_;
    return os;
  }
  os << first.numerator_ << '/' << first.denominator_;
  return os;
}