#pragma once
#include <stdexcept>

class RationalDivisionByZero : public std::runtime_error {
 public:
  RationalDivisionByZero() : std::runtime_error("RationalDivisionByZero") {
  }
};

class Rational {
  int32_t numerator_;
  int32_t denominator_;

 public:
  Rational();
  Rational(int32_t numerator);  // NOLINT
  Rational(int32_t numerator, int32_t denominator);
  int32_t GetNumerator() const;
  int32_t GetDenominator() const;
  void SetNumerator(int32_t numerator);
  void SetDenominator(int32_t denominator);
  void ShortFrac(int32_t& numerator, int32_t& denominator);
  friend Rational operator+(Rational first, Rational second);
  friend Rational operator-(Rational first, Rational second);
  friend Rational operator/(Rational first, Rational second);
  friend Rational operator*(Rational first, Rational second);
  friend Rational& operator+=(Rational& first, Rational second);
  friend Rational& operator-=(Rational& first, Rational second);
  friend Rational& operator*=(Rational& first, Rational second);
  friend Rational& operator/=(Rational& first, Rational second);
  friend Rational operator+(const Rational& first);
  friend Rational operator-(const Rational& first);
  friend bool operator<(Rational first, Rational second);
  friend bool operator>(Rational first, Rational second);
  friend bool operator<=(Rational first, Rational second);
  friend bool operator>=(Rational first, Rational second);
  friend bool operator==(Rational first, Rational second);
  friend bool operator!=(Rational first, Rational second);
  friend Rational operator++(Rational& first, int);
  friend Rational& operator++(Rational& first);
  friend Rational operator--(Rational& first, int);
  friend Rational& operator--(Rational& first);
  friend std::istream& operator>>(std::istream& is, Rational& value);
  friend std::ostream& operator<<(std::ostream& os, const Rational& first);
};