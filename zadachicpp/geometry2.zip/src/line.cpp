#include "../line.h"
#include "../segment.h"
#include <iostream>

namespace geometry {
Line& Line::Move(const Vector& a) {
  first_.x_ += a.v_x_;
  first_.y_ += a.v_y_;
  second_.x_ += a.v_x_;
  second_.y_ += a.v_y_;
  return *this;
}

bool Line::ContainsPoint(const Point& a) const {
  return BelongsLine(first_, second_, a);
}
bool CrossingLineSegment(Point begin_a, Point end_a, Point begin_b, Point end_b) {
  return VectorMultiply(begin_a, end_a, begin_a, end_b) * VectorMultiply(begin_a, end_a, begin_a, begin_b) <= 0;
}
bool Line::CrossesSegment(const Segment& a) const {
  return CrossingLineSegment(first_, second_, a.a_, a.b_);
}
Line* Line::Clone() const {
  auto copy = new Line(first_, second_);
  return copy;
}
std::string Line::ToString() const {
  std::string str = "Line(";
  std::string str1 = std::to_string(second_.y_ - first_.y_);
  std::string str2 = std::to_string(-(second_.x_ - first_.x_));
  std::string str3 = std::to_string(-first_.x_ * (second_.y_ - first_.y_) + first_.y_ * (second_.x_ - first_.x_));
  str += str1;
  str += ", ";
  str += str2;
  str += ", ";
  str += str3;
  str += ")";
  return str;
}
}  // namespace geometry
