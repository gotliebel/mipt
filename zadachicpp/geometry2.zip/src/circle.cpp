#include "../circle.h"
#include "../segment.h"
#include <iostream>
#include <cmath>

namespace geometry {
Circle& Circle::Move(const Vector& a) {
  center_.x_ += a.v_x_;
  center_.y_ += a.v_y_;
  return *this;
}
bool Circle::ContainsPoint(const Point& a) const {
  return (sqrt((center_.x_ - a.x_) * (center_.x_ - a.x_) + (center_.y_ - a.y_) * (center_.y_ - a.y_)) <= radius_);
}

double DistanceSegment(Point a, Point b, Point c) {
  if (((c.x_ - a.x_) * (b.x_ - a.x_) + (c.y_ - a.y_) * (b.y_ - a.y_) >= 0) &&
      ((c.x_ - b.x_) * (a.x_ - b.x_) + (c.y_ - b.y_) * (a.y_ - b.y_)) >= 0) {
    return std::abs((b.x_ - a.x_) * (c.y_ - a.y_) - (b.y_ - a.y_) * (c.x_ - a.x_)) /
           sqrt((b.x_ - a.x_) * (b.x_ - a.x_) + (b.y_ - a.y_) * (b.y_ - a.y_));
  }
  return std::min(sqrt((c.x_ - a.x_) * (c.x_ - a.x_) + (c.y_ - a.y_) * (c.y_ - a.y_)),
                  sqrt((c.x_ - b.x_) * (c.x_ - b.x_) + (c.y_ - b.y_) * (c.y_ - b.y_)));
}
bool Circle::CrossesSegment(const Segment& a) const {
  if (DistanceSegment(a.a_, a.b_, center_) <= radius_) {
    return (sqrt((center_.x_ - a.a_.x_) * (center_.x_ - a.a_.x_) + (center_.y_ - a.a_.y_) * (center_.y_ - a.a_.y_)) >=
                radius_ ||
            sqrt((center_.x_ - a.b_.x_) * (center_.x_ - a.b_.x_) + (center_.y_ - a.b_.y_) * (center_.y_ - a.b_.y_)) >=
                radius_);
  }
  return false;
}
Circle* Circle::Clone() const {
  auto copy = new Circle(center_, radius_);
  return copy;
}
std::string Circle::ToString() const {
  std::string str = "Circle(Point(";
  std::string str1 = std::to_string(center_.x_);
  str += str1;
  str += ", ";
  str1 = std::to_string(center_.y_);
  str += str1;
  str += "), ";
  str1 = std::to_string(radius_);
  str += str1;
  str += ")";
  return str;
}
}  // namespace geometry