#include "../vector.h"
#include <iostream>
namespace geometry {

Vector operator+(const Vector a, const Vector b) {
  Vector final;
  final.v_x_ = a.v_x_ + b.v_x_;
  final.v_y_ = a.v_y_ + b.v_y_;
  return final;
}
Vector operator-(const Vector a, const Vector b) {
  Vector final;
  final.v_x_ = b.v_x_ - a.v_x_;
  final.v_y_ = b.v_y_ - a.v_y_;
  return final;
}
Vector operator*(int64_t number, const Vector a) {
  Vector final;
  final.v_x_ = a.v_x_ * number;
  final.v_y_ = a.v_y_ * number;
  return final;
}
Vector operator/(const Vector a, int64_t number) {
  Vector final;
  final.v_x_ = a.v_x_ / number;
  final.v_y_ = a.v_y_ / number;
  return final;
}
Vector& operator+=(Vector& first, Vector second) {
  first.v_x_ += second.v_x_;
  first.v_y_ += second.v_y_;
  return first;
}
Vector& operator-=(Vector& first, Vector second) {
  first.v_x_ -= second.v_x_;
  first.v_y_ -= second.v_y_;
  return first;
}
Vector& operator*=(Vector& first, int64_t number) {
  first.v_x_ = first.v_x_ * number;
  first.v_y_ = first.v_y_ * number;
  return first;
}
Vector& operator/=(Vector& first, int64_t number) {
  first.v_x_ = first.v_x_ / number;
  first.v_y_ = first.v_y_ / number;
  return first;
}
bool operator==(const Vector first, const Vector second) {
  return first.v_x_ == second.v_x_ && first.v_y_ == second.v_y_;
}
bool operator!=(const Vector first, const Vector second) {
  return !(first.v_x_ == second.v_x_ && first.v_y_ == second.v_y_);
}
Vector operator+(const Vector& a) {
  return a;
}
Vector operator-(const Vector& a) {
  Vector final(a.v_x_, a.v_y_);
  final.v_x_ = -final.v_x_;
  final.v_y_ = -final.v_y_;
  return final;
}
}  // namespace geometry