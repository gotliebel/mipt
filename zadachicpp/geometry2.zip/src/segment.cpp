#include "../segment.h"
#include <iostream>

namespace geometry {
Segment& Segment::Move(const Vector& a) {
  a_.Move(a);
  b_.Move(a);
  return *this;
}
bool Segment::ContainsPoint(const Point& a) const {
  if (a_ == b_) {
    return a_ == a;
  }
  return BelongsSegment(a_, b_, a);
}
bool Segment::CrossesSegment(const Segment& a) const {
  if (a_ == b_ && !(a.a_ == a.b_)) {
    return BelongsSegment(a.a_, a.b_, a_);
  }
  if (!(a_ == b_) && a.a_ == a.b_) {
    return BelongsSegment(a_, b_, a.a_);
  }
  if (a_ == b_ && a.a_ == a.b_) {
    return a_ == a.a_;
  }
  return CrossingSegments(a_, b_, a.a_, a.b_);
}
Segment* Segment::Clone() const {
  auto copy = new Segment(a_, b_);
  return copy;
}
std::string Segment::ToString() const {
  std::string str = "Segment(Point(";
  std::string str1 = std::to_string(a_.x_);
  str += str1;
  str += ", ";
  str1 = std::to_string(a_.y_);
  str += str1;
  str += "), Point(";
  str1 = std::to_string(b_.x_);
  str += str1;
  str += ", ";
  str1 = std::to_string(b_.y_);
  str += str1;
  str += "))";
  return str;
}
}  // namespace geometry