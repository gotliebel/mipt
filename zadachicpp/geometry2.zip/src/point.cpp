#include "../point.h"
#include <iostream>
#include "../segment.h"

namespace geometry {
Vector Point::operator-(const Point& a) const {
  Vector final = {};
  final.v_x_ = x_ - a.x_;
  final.v_y_ = y_ - a.y_;
  return final;
}
Point& Point::Move(const Vector& a) {
  x_ += a.v_x_;
  y_ += a.v_y_;
  return *this;
}
bool Point::ContainsPoint(const Point& a) const {
  return x_ == a.x_ && y_ == a.y_;
}
bool operator==(const Point a, const Point b) {
  return a.x_ == b.x_ && a.y_ == b.y_;
}
bool Point::CrossesSegment(const Segment& a) const {
  Point check(x_, y_);
  return BelongsSegment(a.a_, a.b_, check);
}
Point* Point::Clone() const {
  auto copy = new Point(x_, y_);
  return copy;
}
std::string Point::ToString() const {
  std::string str = "Point(";
  std::string str1 = std::to_string(x_);
  str += str1;
  str += ", ";
  str1 = std::to_string(y_);
  str += str1;
  str += ")";
  return str;
}
}  // namespace geometry
