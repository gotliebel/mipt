#include "../polygon.h"
#include "../segment.h"
#include <iostream>

namespace geometry {
Polygon& Polygon::Move(const Vector& a) {
  int size = v_.size();
  for (int i = 0; i < size; ++i) {
    v_[i].x_ += a.v_x_;
    v_[i].y_ += a.v_y_;
  }
  return *this;
}
bool Polygon::ContainsPoint(const Point& check) const {
  int n = v_.size();
  Point largest_point(100000000, check.y_ + 1);
  bool is_yes = false;
  int counter = 0;
  for (int i = 0; i < n - 1; ++i) {
    if (BelongsSegment(v_[i], v_[i + 1], check)) {
      is_yes = true;
    }
    if (CrossingSegments(check, largest_point, v_[i], v_[i + 1])) {
      counter++;
    }
  }
  if (CrossingSegments(check, largest_point, v_[n - 1], v_[0])) {
    counter++;
  }
  if (is_yes) {
    return true;
  }
  return counter % 2 != 0;
}
bool Polygon::CrossesSegment(const Segment& a) const {
  int n = v_.size();
  for (int i = 0; i < n - 1; ++i) {
    if (CrossingSegments(v_[i], v_[i + 1], a.a_, a.b_)) {
      return true;
    }
  }
  return CrossingSegments(v_[0], v_[n - 1], a.a_, a.b_);
}
Polygon* Polygon::Clone() const {
  auto copy = new Polygon(v_);
  return copy;
}
std::string Polygon::ToString() const {
  std::string str = "Polygon(";
  int n = v_.size();
  std::string str1;
  for (int i = 0; i < n; ++i) {
    str += "Point(";
    str1 = std::to_string(v_[i].x_);
    str += str1;
    str += ", ";
    str1 = std::to_string(v_[i].y_);
    str += str1;
    str += "), ";
  }
  str.pop_back();
  str.pop_back();
  str += ")";
  return str;
}
}  // namespace geometry
