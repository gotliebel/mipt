#ifndef OOP_ASSIGNMENTS_SEGMENT_H
#define OOP_ASSIGNMENTS_SEGMENT_H
#pragma once

#include "ishape.h"
#include "point.h"

namespace geometry {
class Segment : public IShape {
 public:
  Point a_;
  Point b_;
  Segment() = default;
  Segment(Point a, Point b) : a_(a), b_(b){};
  Segment& Move(const Vector&) override;
  bool ContainsPoint(const Point&) const override;
  bool CrossesSegment(const Segment&) const override;
  Segment* Clone() const override;
  std::string ToString() const override;
};
inline int64_t VectorMultiply(Point begin_first, Point end_first, Point begin_second, Point end_second) {
  return (end_first.x_ - begin_first.x_) * (end_second.y_ - begin_second.y_) -
         (end_first.y_ - begin_first.y_) * (end_second.x_ - begin_second.x_);
}
inline bool BelongsLine(Point a, Point b, Point c) {
  return c.x_ * (b.y_ - a.y_) - a.x_ * (b.y_ - a.y_) - c.y_ * (b.x_ - a.x_) + a.y_ * (b.x_ - a.x_) == 0;
}
inline bool BelongsRay(Point a, Point b, Point c) {
  return (BelongsLine(a, b, c) && ((a.x_ - c.x_) * (b.x_ - a.x_) + (a.y_ - c.y_) * (b.y_ - a.y_) <= 0));
}
inline bool BelongsSegment(Point a, Point b, Point c) {
  return (BelongsRay(a, b, c) && (b.x_ - c.x_) * (b.x_ - a.x_) + (b.y_ - c.y_) * (b.y_ - a.y_) >= 0);
}
inline int64_t ScalarMultiply(Point begin_first, Point end_first, Point begin_second, Point end_second) {
  return (end_first.x_ - begin_first.x_) * (end_second.x_ - begin_second.x_) +
         (end_first.y_ - begin_first.y_) * (end_second.y_ - begin_second.y_);
}
inline bool CrossingSegments(Point begin_a, Point end_a, Point begin_b, Point end_b) {
  if (VectorMultiply(begin_a, end_a, begin_a, end_b) * VectorMultiply(begin_a, end_a, begin_a, begin_b) < 0 &&
      VectorMultiply(begin_b, end_b, begin_b, begin_a) * VectorMultiply(begin_b, end_b, begin_b, end_a) < 0) {
    return true;
  }
  if (VectorMultiply(begin_a, end_a, begin_a, end_b) * VectorMultiply(begin_a, end_a, begin_a, begin_b) == 0 ||
      VectorMultiply(begin_b, end_b, begin_b, begin_a) * VectorMultiply(begin_b, end_b, begin_b, end_a) == 0) {
    if ((VectorMultiply(begin_a, end_a, begin_a, begin_b) == 0 &&
         ScalarMultiply(begin_b, begin_a, begin_b, end_a) <= 0) ||
        (VectorMultiply(begin_a, end_a, begin_a, end_b) == 0 && ScalarMultiply(end_b, begin_a, end_b, end_a) <= 0) ||
        (VectorMultiply(begin_b, end_b, begin_b, begin_a) == 0 &&
         ScalarMultiply(begin_a, begin_b, begin_a, end_b) <= 0) ||
        (VectorMultiply(begin_b, end_b, begin_b, end_a) == 0 && ScalarMultiply(end_a, begin_b, end_a, end_b) <= 0)) {
      return true;
    }
  }
  return false;
}
}  // namespace geometry
#endif
