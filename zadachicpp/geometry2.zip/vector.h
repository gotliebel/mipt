#ifndef OOP_ASSIGNMENTS_VECTOR_H
#define OOP_ASSIGNMENTS_VECTOR_H
#pragma once

#include <iostream>
#include "ishape.h"

namespace geometry {
class Point;
class Vector {
 public:
  double v_x_;
  double v_y_;
  Vector() = default;
  Vector(double a, double b) : v_x_(a), v_y_(b){};
  friend Vector operator+(const Vector a, const Vector b);
  friend Vector operator-(const Vector a, const Vector b);
  friend Vector operator*(int64_t number, const Vector a);
  friend Vector& operator+=(Vector& first, Vector second);
  friend Vector& operator-=(Vector& first, Vector second);
  friend Vector& operator*=(Vector& first, int64_t number);
  friend Vector& operator/=(Vector& first, int64_t number);
  friend bool operator==(const Vector first, const Vector second);
  friend bool operator!=(const Vector first, const Vector second);
  friend Vector operator+(const Vector& a);
  friend Vector operator-(const Vector& a);
};
}  // namespace geometry
#endif
