#ifndef OOP_ASSIGNMENTS_LINE_H
#define OOP_ASSIGNMENTS_LINE_H
#pragma once

#include "ishape.h"
#include "point.h"

namespace geometry {
class Line : public IShape {
 public:
  Point first_;
  Point second_;
  Line() = default;
  Line(Point a, Point b) : first_(a), second_(b){};
  Line& Move(const Vector&) override;
  bool ContainsPoint(const Point&) const override;
  bool CrossesSegment(const Segment&) const override;
  Line* Clone() const override;
  std::string ToString() const override;
};
}  // namespace geometry
#endif
