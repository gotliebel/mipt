#ifndef OOP_ASSIGNMENTS_CIRCLE_H
#define OOP_ASSIGNMENTS_CIRCLE_H
#pragma once

#include "ishape.h"
#include "point.h"

namespace geometry {
class Circle : public IShape {
 public:
  Point center_;
  int64_t radius_;
  Circle() = default;
  Circle(Point a, int64_t rad) : radius_(rad) {
    center_.x_ = a.x_;
    center_.y_ = a.y_;
  };
  Circle& Move(const Vector&) override;
  bool ContainsPoint(const Point&) const override;
  bool CrossesSegment(const Segment&) const override;
  Circle* Clone() const override;
  std::string ToString() const override;
};
}  // namespace geometry
#endif
