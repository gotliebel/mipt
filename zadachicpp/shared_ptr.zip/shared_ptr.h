#include <stdexcept>
#include <iostream>
#pragma once

class BadWeakPtr : public std::runtime_error {
 public:
  BadWeakPtr() : std::runtime_error("BadWeakPtr") {
  }
};

template <class T>
class SharedPtr {
  T* data_;
  int* counter_;

 public:
  SharedPtr() noexcept : data_(nullptr), counter_(nullptr){};
  explicit SharedPtr(T* data) : data_(data), counter_(new int(1)) {
  }
  SharedPtr(const SharedPtr& other) : data_(other.data_), counter_(other.counter_) {
    if (other.data_ != nullptr) {
      ++*counter_;
    }
  }
  SharedPtr(std::nullptr_t) : data_(nullptr), counter_(nullptr){};  // NOLINT
  void Swap(SharedPtr<T>& other) {
    std::swap(data_, other.data_);
    std::swap(counter_, other.counter_);
  }
  SharedPtr(SharedPtr&& other) noexcept : SharedPtr() {
    Swap(other);
  }
  SharedPtr& operator=(SharedPtr other) noexcept {
    Swap(other);
    return *this;
  }
  ~SharedPtr() {
    if (data_ == nullptr) {
      return;
    }
    --*counter_;
    if (*counter_ == 0) {
      delete data_;
      delete counter_;
    }
  }
  void Reset(T* ptr = nullptr) {
    T* prev = data_;
    data_ = ptr;
    if (counter_ != nullptr) {
      --*counter_;
    }
    if (counter_ != nullptr && *counter_ == 0) {
      delete prev;
      delete counter_;
    }
    if (data_ == nullptr) {
      counter_ = nullptr;
    } else {
      counter_ = new int(1);
    }
  }
  T* Get() const {
    return data_;
  }
  int UseCount() const {
    if (counter_ == nullptr) {
      return 0;
    }
    return *counter_;
  }

  T& operator*() const {
    return *data_;
  }
  T* operator->() const {
    return data_;
  }
  explicit operator bool() const {
    return data_ != nullptr;
  }
};