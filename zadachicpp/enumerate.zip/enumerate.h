#pragma once

template <class Iterator>
class EnumerateIterator {
 private:
  Iterator iterator_;
  size_t index_;

 public:
  EnumerateIterator() = default;
  explicit EnumerateIterator(const Iterator& iterator) : iterator_(iterator), index_(0){};

  EnumerateIterator& operator++() {
    ++index_;
    ++iterator_;
    return *this;
  }
  EnumerateIterator operator++(int) {
    auto tmp = *this;
    index_++;
    iterator_++;
    return tmp;
  }
  EnumerateIterator& operator--() {
    --index_;
    --iterator_;
    return *this;
  }
  EnumerateIterator operator--(int) {
    auto tmp = *this;
    index_--;
    iterator_--;
    return tmp;
  }
  auto operator*() const {
    return std::pair<size_t, decltype(*iterator_)>(index_, *iterator_);
  }
  bool operator==(const EnumerateIterator& other) {
    return iterator_ == other.iterator_;
  }
  bool operator!=(const EnumerateIterator& other) {
    return !(*this == other);
  }
};
template <class T>
class Enumerate {
 private:
  T* buffer_;

 public:
  explicit Enumerate(T& container) : buffer_(&container){};
  auto begin() const {  // NOLINT
    return EnumerateIterator<decltype(buffer_->begin())>(buffer_->begin());
  }
  auto end() const {  // NOLINT
    return EnumerateIterator<decltype(buffer_->end())>(buffer_->end());
  }
  auto begin() {  // NOLINT
    return EnumerateIterator<decltype(buffer_->begin())>(buffer_->begin());
  }
  auto end() {  // NOLINT
    return EnumerateIterator<decltype(buffer_->end())>(buffer_->end());
  }
};