#ifndef OOP_ASSIGNMENTS_GCD_H
#define OOP_ASSIGNMENTS_GCD_H

template <class T>
T Gcd(T x, T y) {
  if (x == 0) {
    return y;
  }
  if (y == 0) {
    return x;
  }
  if (x > y) {
    x = x % y;
    return Gcd(x, y);
  }
  y = y % x;
  return Gcd(x, y);
}

#endif